"console.log('Hello Azure')" 
